package com.example.endingwork.bean;

public class UserInfo {
    public long rowid;
    public String name;
    public String update_time;
    public String phone;
    public String pwd;

    public UserInfo() {
        rowid = 0L;
        name = "";
        update_time = "";
        phone = "";
        pwd = "";
    }
}